Public Class pathFinder

    Private path As New ArrayList
    Private isPathFound As Boolean = False
    Private field() As Integer
    Private frontWaveSet As New ArrayList
    Private newFrontWaveSet As New ArrayList
    Private cc As Integer = 0
    Private mForm As mainForm
    Private forthNode As Node

    'default constructor
    Public Sub New()
        'default initialisation
    End Sub

    'constructor
    Public Sub New(ByVal field() As Integer, ByVal mf As mainForm)
        Me.field = field
        mForm = mf
    End Sub

    'look for path and return true if exists
    Public Function findPath(ByVal source As Integer, ByVal destination As Integer) As Boolean
        Dim i As Integer = 0
        Dim solution As Node = Nothing

        'reset isPathFound
        isPathFound = False

        'set the source
        frontWaveSet.Add(CType(calculateChildren(New Node(Nothing, 0, source)), Node))

        'wave's dynamic
        While isPathFound = False And i < mainForm.NUM_OF_FIELDS
            solution = nextStep(destination)
            i += 1
        End While

        'get path out of solution
        If isPathFound = True Then
            While Not solution Is Nothing
                path.Add(solution.Location)
                solution = solution.Parent
            End While
        End If

        path.Reverse()

        Return isPathFound
    End Function

    'get one step further
    Private Function nextStep(ByVal destination As Integer) As Node
        Dim i As Integer
        Dim j As Integer
        Dim node As Node
        Dim l As Boolean = False, c As Boolean = False, r As Boolean = False

        'wave's next move
        For i = 1 To frontWaveSet.Count
            node = CType(frontWaveSet(i - 1), Node)
            node = calculateChildren(node)

            'see if reach the destination
            If node.Location = destination Then
                isPathFound = True
                Return node
            End If

            l = False : c = False : r = False

            'scan for duplicates
            For j = 1 To newFrontWaveSet.Count
                If CType(newFrontWaveSet(j - 1), Node).compareNodes(node.Left) = True Then l = True
                If CType(newFrontWaveSet(j - 1), Node).compareNodes(node.Centre) = True Then c = True
                If CType(newFrontWaveSet(j - 1), Node).compareNodes(node.Right) = True Then r = True
            Next

            'set next front wave excluding duplicates
            If l = False And Not node.Left Is Nothing Then newFrontWaveSet.Add(node.Left)
            If c = False And Not node.Centre Is Nothing Then newFrontWaveSet.Add(node.Centre)
            If r = False And Not node.Right Is Nothing Then newFrontWaveSet.Add(node.Right)

            'special case
            If Not forthNode Is Nothing Then newFrontWaveSet.Add(forthNode)
        Next

        'set new front wave
        frontWaveSet = newFrontWaveSet
        newFrontWaveSet = Nothing
        newFrontWaveSet = New ArrayList

        Return Nothing
    End Function

    'calculate children for any given node.
    'NOTE: root will have only 3 directions instead of 4(happens sometime)
    Private Function calculateChildren(ByVal node As Node) As Node
        Dim newNode As Node

        Dim childLocation(3) As Integer
        Dim potentialLocation(3) As Integer
        Dim i As Integer = 0
        Dim count As Integer = 0

        Dim newLoc As Integer = 0
        Dim result As Integer = 0
        Dim reminder As Integer = 0

        'initialize new node with children
        newNode = New Node(node.Parent, node.Distance, node.Location)
        newNode.Left = Nothing
        newNode.Centre = Nothing
        newNode.Right = Nothing

        'calculate potential locations
        potentialLocation(0) = node.Location - mainForm.SIZE_OF_ROW     ' 0"
        potentialLocation(1) = node.Location + 1                        ' 15"
        potentialLocation(2) = node.Location + mainForm.SIZE_OF_ROW     ' 30"
        potentialLocation(3) = node.Location - 1                        ' 45"

        'check for the left/right borders of the field
        result = Math.DivRem(node.Location, mainForm.SIZE_OF_ROW, reminder)

        'it's vb's fault
        If node.Parent Is Nothing Then
            If potentialLocation(0) > 0 Then
                If field(potentialLocation(0)) = mForm.EMPTY_SPACE Then
                    childLocation(i) = potentialLocation(0)
                    i += 1
                End If
            End If
            If reminder < (mainForm.SIZE_OF_ROW - 1) Then
                If field(potentialLocation(1)) = mForm.EMPTY_SPACE Then
                    childLocation(i) = potentialLocation(1)
                    i += 1
                End If
            End If
            If potentialLocation(2) < mainForm.NUM_OF_FIELDS Then
                If field(potentialLocation(2)) = mForm.EMPTY_SPACE Then
                    childLocation(i) = potentialLocation(2)
                    i += 1
                End If
            End If
            If reminder > 0 Then
                If field(potentialLocation(3)) = mForm.EMPTY_SPACE Then
                    childLocation(i) = potentialLocation(3)
                    i += 1
                End If
            End If
        Else
            If potentialLocation(0) >= 0 And potentialLocation(0) <> node.Parent.Location Then
                If field(potentialLocation(0)) = mForm.EMPTY_SPACE Then
                    childLocation(i) = potentialLocation(0)
                    i += 1
                End If
            End If
            If reminder < (mainForm.SIZE_OF_ROW - 1) And potentialLocation(1) <> node.Parent.Location Then
                If field(potentialLocation(1)) = mForm.EMPTY_SPACE Then
                    childLocation(i) = potentialLocation(1)
                    i += 1
                End If
            End If
            If potentialLocation(2) < mainForm.NUM_OF_FIELDS And _
               potentialLocation(2) <> node.Parent.Location Then
                If field(potentialLocation(2)) = mForm.EMPTY_SPACE Then
                    childLocation(i) = potentialLocation(2)
                    i += 1
                End If
            End If
            If reminder > 0 And potentialLocation(3) <> node.Parent.Location Then
                If field(potentialLocation(3)) = mForm.EMPTY_SPACE Then
                    childLocation(i) = potentialLocation(3)
                    i += 1
                End If
            End If
        End If

        If (i - 1) >= 0 Then newNode.Left = New Node(node, node.Distance + 1, childLocation(0))
        If (i - 1) >= 1 Then newNode.Centre = New Node(node, node.Distance + 1, childLocation(1))
        If (i - 1) >= 2 Then newNode.Right = New Node(node, node.Distance + 1, childLocation(2))

        'special case
        If (i - 1) >= 3 And node.Parent Is Nothing Then
            forthNode = New Node(node, node.Distance + 1, childLocation(3))
        Else
            forthNode = Nothing
        End If


        Return newNode
    End Function

    'gets the path to destination if exists
    Public ReadOnly Property getPath() As Integer()
        Get
            If isPathFound = True Then
                Return path.ToArray(Type.GetType("System.Int32"))
            Else
                Return Nothing
            End If
        End Get
    End Property
End Class

Public NotInheritable Class Node
    Private parentNode As Node
    Private distanceFromSource As Integer
    Protected fieldLocation As Integer
    Private nextLeft As Node = Nothing
    Private nextCentre As Node = Nothing
    Private nextRight As Node = Nothing

    Public Sub New(ByVal theParent As Node, ByVal theDistance As Integer)
        parentNode = theParent
        distanceFromSource = theDistance
    End Sub

    Public Sub New(ByVal theParent As Node, ByVal theDistance As Integer, ByVal theLocation As Integer)
        parentNode = theParent
        distanceFromSource = theDistance
        fieldLocation = theLocation
    End Sub

    Public Function compareNodes(ByVal source As Node) As Boolean
        If source Is Nothing Then Return False
        If fieldLocation = source.fieldLocation And distanceFromSource = source.Distance Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Property Location() As Integer
        Get
            Return fieldLocation
        End Get
        Set(ByVal Value As Integer)
            fieldLocation = Value
        End Set
    End Property

    Public Property Left() As Node
        Get
            Return nextLeft
        End Get
        Set(ByVal Value As Node)
            nextLeft = Value
        End Set
    End Property

    Public Property Centre() As Node
        Get
            Return nextCentre
        End Get
        Set(ByVal Value As Node)
            nextCentre = Value
        End Set
    End Property

    Public Property Right() As Node
        Get
            Return nextRight
        End Get
        Set(ByVal Value As Node)
            nextRight = Value
        End Set
    End Property

    Public Property Distance() As Integer
        Get
            Return distanceFromSource
        End Get
        Set(ByVal Value As Integer)
            distanceFromSource = Value
        End Set
    End Property

    Public ReadOnly Property Parent() As Node
        Get
            Return parentNode
        End Get
    End Property

    Public Overrides Function ToString() As String
        Dim str As String

        If Not parentNode Is Nothing Then
            str += "Parent Node: " + parentNode.ToString
        Else
            str += "Parent Node: Nothing"
        End If
        str += " | distanceFromSource: " + distanceFromSource.ToString
        str += " | fieldLocation: " + fieldLocation.ToString

        If Not nextLeft Is Nothing Then
            str += " | Left Node: " + nextLeft.ToString
        Else
            str += " | Left Node: Nothing"
        End If

        If Not nextCentre Is Nothing Then
            str += " | Centre Node: " + nextCentre.ToString
        Else
            str += " | Centre Node: Nothing"
        End If

        If Not nextRight Is Nothing Then
            str += " | Right Node: " + nextRight.ToString + vbCrLf
        Else
            str += " | Right Node: Nothing" + vbCrLf
        End If

        Return str
    End Function
End Class
