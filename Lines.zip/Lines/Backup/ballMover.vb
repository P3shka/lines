Imports System.Threading

Public Class ballMover

    Private moves() As Integer
    Private imageIndex As Integer
    Private field As mainForm

    Public Sub New()
        'default constructor
    End Sub

    Public Sub New(ByVal indexArray() As Integer, ByVal imageIndex As Integer, ByVal field As mainForm)
        moves = indexArray
        Me.imageIndex = imageIndex
        Me.field = field
    End Sub

    'showtime
    Public Sub go()
        Dim i As Integer = 0
        Dim len As Integer = moves.Length

        For i = 1 To moves.Length
            CType(field.Panel1.Controls.Item(moves(i - 1)), Label).ImageIndex() = imageIndex
            CType(field.Panel1.Controls.Item(moves(i - 1)), Label).Refresh()
            Thread.Sleep(120)
            If i < moves.Length Then
                CType(field.Panel1.Controls.Item(moves(i - 1)), Label).ImageIndex() = field.EMPTY_SPACE
                CType(field.Panel1.Controls.Item(moves(i - 1)), Label).Refresh()
            End If
        Next
    End Sub
End Class
