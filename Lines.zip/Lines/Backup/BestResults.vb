Public Class BestResults
    Inherits System.Windows.Forms.Form

    Private resultToCheck As Integer = 0
    Private topResults As New System.Collections.Specialized.NameValueCollection
    Private isTopResults As Boolean = False

#Region " Windows Form Designer generated code "

    'this is to call if you want to display Best Results
    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        LoadResults()

    End Sub

    'this is to call if you want to check the result
    Public Sub New(ByVal result As Integer)
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        resultToCheck = result
        LoadResults()

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
    Friend WithEvents ButtonOK As System.Windows.Forms.Button
    Friend WithEvents ButtonReset As System.Windows.Forms.Button
    Friend WithEvents topTenLabel As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.topTenLabel = New System.Windows.Forms.Label
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.TextBox3 = New System.Windows.Forms.TextBox
        Me.TextBox4 = New System.Windows.Forms.TextBox
        Me.TextBox5 = New System.Windows.Forms.TextBox
        Me.TextBox6 = New System.Windows.Forms.TextBox
        Me.TextBox7 = New System.Windows.Forms.TextBox
        Me.TextBox8 = New System.Windows.Forms.TextBox
        Me.TextBox9 = New System.Windows.Forms.TextBox
        Me.TextBox10 = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.ButtonOK = New System.Windows.Forms.Button
        Me.ButtonReset = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'TextBox1
        '
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(48, 48)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(96, 13)
        Me.TextBox1.TabIndex = 1
        Me.TextBox1.TabStop = False
        Me.TextBox1.Text = "TextBox1"
        '
        'topTenLabel
        '
        Me.topTenLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.topTenLabel.Location = New System.Drawing.Point(64, 16)
        Me.topTenLabel.Name = "topTenLabel"
        Me.topTenLabel.Size = New System.Drawing.Size(136, 23)
        Me.topTenLabel.TabIndex = 35
        Me.topTenLabel.Text = "Top 10 players:"
        '
        'TextBox2
        '
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.Location = New System.Drawing.Point(48, 66)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ReadOnly = True
        Me.TextBox2.Size = New System.Drawing.Size(96, 13)
        Me.TextBox2.TabIndex = 2
        Me.TextBox2.TabStop = False
        Me.TextBox2.Text = "TextBox2"
        '
        'TextBox3
        '
        Me.TextBox3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox3.Location = New System.Drawing.Point(48, 84)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.ReadOnly = True
        Me.TextBox3.Size = New System.Drawing.Size(96, 13)
        Me.TextBox3.TabIndex = 3
        Me.TextBox3.TabStop = False
        Me.TextBox3.Text = "TextBox3"
        '
        'TextBox4
        '
        Me.TextBox4.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox4.Location = New System.Drawing.Point(48, 102)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.ReadOnly = True
        Me.TextBox4.Size = New System.Drawing.Size(96, 13)
        Me.TextBox4.TabIndex = 4
        Me.TextBox4.TabStop = False
        Me.TextBox4.Text = "TextBox4"
        '
        'TextBox5
        '
        Me.TextBox5.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox5.Location = New System.Drawing.Point(48, 120)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.ReadOnly = True
        Me.TextBox5.Size = New System.Drawing.Size(96, 13)
        Me.TextBox5.TabIndex = 5
        Me.TextBox5.TabStop = False
        Me.TextBox5.Text = "TextBox5"
        '
        'TextBox6
        '
        Me.TextBox6.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox6.Location = New System.Drawing.Point(48, 138)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.ReadOnly = True
        Me.TextBox6.Size = New System.Drawing.Size(96, 13)
        Me.TextBox6.TabIndex = 6
        Me.TextBox6.TabStop = False
        Me.TextBox6.Text = "TextBox6"
        '
        'TextBox7
        '
        Me.TextBox7.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox7.Location = New System.Drawing.Point(48, 156)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.ReadOnly = True
        Me.TextBox7.Size = New System.Drawing.Size(96, 13)
        Me.TextBox7.TabIndex = 7
        Me.TextBox7.TabStop = False
        Me.TextBox7.Text = "TextBox7"
        '
        'TextBox8
        '
        Me.TextBox8.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox8.Location = New System.Drawing.Point(48, 174)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.ReadOnly = True
        Me.TextBox8.Size = New System.Drawing.Size(96, 13)
        Me.TextBox8.TabIndex = 8
        Me.TextBox8.TabStop = False
        Me.TextBox8.Text = "TextBox8"
        '
        'TextBox9
        '
        Me.TextBox9.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox9.Location = New System.Drawing.Point(48, 192)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.ReadOnly = True
        Me.TextBox9.Size = New System.Drawing.Size(96, 13)
        Me.TextBox9.TabIndex = 9
        Me.TextBox9.TabStop = False
        Me.TextBox9.Text = "TextBox9"
        '
        'TextBox10
        '
        Me.TextBox10.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox10.Location = New System.Drawing.Point(48, 210)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.ReadOnly = True
        Me.TextBox10.Size = New System.Drawing.Size(96, 13)
        Me.TextBox10.TabIndex = 10
        Me.TextBox10.TabStop = False
        Me.TextBox10.Text = "TextBox10"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(144, 48)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(56, 13)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Label1"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(144, 66)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(56, 13)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "Label2"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(144, 84)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 13)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "Label3"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(144, 102)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(56, 13)
        Me.Label4.TabIndex = 14
        Me.Label4.Text = "Label4"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(144, 120)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(56, 13)
        Me.Label5.TabIndex = 15
        Me.Label5.Text = "Label5"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(144, 138)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(56, 13)
        Me.Label6.TabIndex = 16
        Me.Label6.Text = "Label6"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(144, 156)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(56, 13)
        Me.Label7.TabIndex = 17
        Me.Label7.Text = "Label7"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(144, 174)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(56, 13)
        Me.Label8.TabIndex = 18
        Me.Label8.Text = "Label8"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(144, 192)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(56, 13)
        Me.Label9.TabIndex = 19
        Me.Label9.Text = "Label9"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label10
        '
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(144, 210)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(56, 13)
        Me.Label10.TabIndex = 20
        Me.Label10.Text = "Label10"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ButtonOK
        '
        Me.ButtonOK.Location = New System.Drawing.Point(208, 48)
        Me.ButtonOK.Name = "ButtonOK"
        Me.ButtonOK.TabIndex = 21
        Me.ButtonOK.Text = "OK"
        '
        'ButtonReset
        '
        Me.ButtonReset.Location = New System.Drawing.Point(208, 80)
        Me.ButtonReset.Name = "ButtonReset"
        Me.ButtonReset.TabIndex = 22
        Me.ButtonReset.Text = "Reset"
        '
        'BestResults
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(298, 240)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.TextBox5)
        Me.Controls.Add(Me.TextBox6)
        Me.Controls.Add(Me.TextBox7)
        Me.Controls.Add(Me.TextBox8)
        Me.Controls.Add(Me.TextBox9)
        Me.Controls.Add(Me.TextBox10)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.ButtonOK)
        Me.Controls.Add(Me.ButtonReset)
        Me.Controls.Add(Me.topTenLabel)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "BestResults"
        Me.ShowInTaskbar = False
        Me.Text = "Best Results"
        Me.TopMost = True
        Me.ResumeLayout(False)

    End Sub

#End Region

    'OK button
    Private Sub ButtonOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonOK.Click
        Dim i As Integer = 0
        Dim key, value As String

        If isTopResults = True Then
            topResults.Clear()
            For i = 0 To 9
                key = CType(Me.Controls.Item(i), TextBox).Text
                value = CType(Me.Controls.Item(i + 10), Label).Text
                topResults.Add(key, value)
            Next
            SaveResults()
        End If
        isTopResults = False
        Me.Close()
    End Sub

    'Reset button
    Private Sub ButtonReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonReset.Click
        Dim i10 As Integer = 10
        Dim i As Integer = 0

        'confirmation message
        Dim result As DialogResult = MessageBox.Show( _
             "You are about to reset all of your top results." + vbCrLf + " Do you want to proceed?", _
             "Reset Top 10", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, Nothing, Nothing)

        If result.Equals(DialogResult.No) = True Then
            Exit Sub
        End If

        topResults.Clear()
        For i = 0 To i10 - 1
            topResults.Add("Unknown" + i.ToString, "0")
            CType(Me.Controls.Item(i), TextBox).Text = "Unknown" + (i + 1).ToString
            CType(Me.Controls.Item(i + 10), Label).Text = CInt(topResults.Item("Unknown" + (i + 1).ToString))
        Next
        isTopResults = True
        ButtonOK_Click(sender, e)
    End Sub

    'Loads results from file
    Private Sub LoadResults()
        Dim i As Integer
        Dim keyBuffer(4) As Byte
        Dim name, value As String
        Dim stream As System.IO.FileStream
        Dim file As System.IO.File

        Try
            stream = file.Open(".\lines.results", IO.FileMode.Open)

            stream.Read(keyBuffer, 0, 5)
            Dim encodedText(stream.Length - 5) As Byte
            stream.Read(encodedText, 0, stream.Length - 4)
            Dim decodedText As String = decode(keyBuffer, encodedText)

            Dim tokens As New StringTokenizer(decodedText, "|")
            i = 0
            name = tokens.nextToken()
            topResults.Clear()
            While name.Equals("") = False
                value = tokens.nextToken
                CType(Me.Controls.Item(i), TextBox).Text = name
                CType(Me.Controls.Item(i + 10), Label).Text = value
                i += 1
                topResults.Add(name, value)
                name = tokens.nextToken()
            End While
            stream.Close()

        Catch e As System.IO.FileNotFoundException
            For i = 0 To 10 - 1
                topResults.Add("Unknown" + i.ToString, "0")
                CType(Me.Controls.Item(i), TextBox).Text = "Unknown" + (i + 1).ToString
                CType(Me.Controls.Item(i + 10), Label).Text = CInt(topResults.Item("Unknown" + (i + 1).ToString))
            Next
            isTopResults = True
        Catch e As Exception
            For i = 0 To 10 - 1
                topResults.Add("Unknown" + i.ToString, "0")
                CType(Me.Controls.Item(i), TextBox).Text = "Unknown" + (i + 1).ToString
                CType(Me.Controls.Item(i + 10), Label).Text = CInt(topResults.Item("Unknown" + (i + 1).ToString))
            Next
            isTopResults = True
            stream.Close()
        End Try
    End Sub

    'Save results into .bin file
    Private Sub SaveResults()
        Dim text As New String("")
        Dim separator As Char = "|"
        Dim encodedText() As Byte
        Dim i As Integer
        Dim keyBuffer(4) As Byte

        If topResults.Count = 0 Then
            For i = 0 To 10 - 1
                topResults.Add(CType(Me.Controls.Item(i), TextBox).Text, _
                CType(Me.Controls.Item(i + 10), Label).Text)
            Next

        End If
        'get Text with separators
        Dim names As IEnumerator = topResults.Keys.GetEnumerator
        For i = 0 To 10 - 1
            names.MoveNext()
            text += names.Current + separator + topResults.Get(names.Current) + separator
        Next

        'get key
        Dim rand As New Random
        rand.NextBytes(keyBuffer)

        'encode text with keyBuffer
        encodedText = encode(keyBuffer, text)

        Dim file As System.IO.File
        Dim stream As System.IO.FileStream = file.Open(".\lines.results", IO.FileMode.Create)

        stream.Write(keyBuffer, 0, 5)
        stream.Write(encodedText, 0, encodedText.Length - 1)
        stream.Flush()
        stream.Close()
    End Sub

    'Check the given result
    'returns true if it is in top10, otherwise false
    Public Function checkResult(ByVal result As Integer) As Boolean
        resultToCheck = result
        Return checkResult()
    End Function

    'check the results
    'returns true if it is in top10, otherwise false
    Public Function checkResult() As Boolean
        Dim i As Integer = 0
        Dim position As Integer = -1
        Dim key As String
        Dim value As String

        'check the result
        If resultToCheck <> 0 Then
            'the situation when top results were reset
            If CType(Me.Controls.Item(10), Label).Text = "0" Then
                CType(Me.Controls.Item(0), TextBox).ReadOnly = False
                CType(Me.Controls.Item(0), TextBox).BorderStyle = BorderStyle.Fixed3D
                CType(Me.Controls.Item(0), TextBox).TabStop = True
                CType(Me.Controls.Item(10), Label).Text = resultToCheck.ToString
                isTopResults = True
                Me.ShowDialog()

                CType(Me.Controls.Item(0), TextBox).TabStop = False
                CType(Me.Controls.Item(0), TextBox).ReadOnly = True
                CType(Me.Controls.Item(0), TextBox).BorderStyle = BorderStyle.None
                Exit Function
            End If

            'if top results were not reset
            For i = 10 To 20 - 1
                value = CType(Me.Controls.Item(i), Label).Text
                If resultToCheck >= Integer.Parse(value) Then
                    position = i - 10
                    Exit For
                End If
            Next

            'we have a winner if position >= 0 (remember it was -1)
            If position >= 0 Then
                'get all positions that are higher than resultTocheck
                For i = 0 To position - 1
                    key = topResults.GetKey(i)
                    CType(Me.Controls.Item(i), TextBox).Text = key
                    CType(Me.Controls.Item(i + 10), Label).Text = topResults.Item(key)
                Next

                'insert resultToCheck
                position = i
                CType(Me.Controls.Item(i), TextBox).ReadOnly = False
                CType(Me.Controls.Item(i), TextBox).BorderStyle = BorderStyle.Fixed3D
                CType(Me.Controls.Item(i), TextBox).TabStop = True
                CType(Me.Controls.Item(i), TextBox).Text = ""
                CType(Me.Controls.Item(i + 10), Label).Text = resultToCheck.ToString

                'insert the rest of the positions. Max = 10th position.
                '-1 states that we start from position 0 not 1
                For i = position To 10 - 1
                    key = topResults.GetKey(i)
                    CType(Me.Controls.Item(i + 1), TextBox).Text = key
                    CType(Me.Controls.Item(i + 10 + 1), Label).Text = topResults.Item(key)
                    If (i + 1) >= 9 Then Exit For
                Next
                isTopResults = True
                Me.ShowDialog()
            End If
        End If
        resultToCheck = 0
        If position >= 0 Then
            CType(Me.Controls.Item(position), TextBox).ReadOnly = True
            CType(Me.Controls.Item(position), TextBox).BorderStyle = BorderStyle.None
            CType(Me.Controls.Item(position), TextBox).TabStop = False
        End If
        Return isTopResults
    End Function

    'text encoder
    Private Function encode(ByVal keyBuff() As Byte, ByVal text As String) As Byte()
        Dim i As Integer
        Dim encodedText As New ArrayList
        Dim count As Integer = text.Trim.Length
        Dim result As Integer, reminder As Integer

        For i = 0 To count - 1
            result = Math.DivRem(i, keyBuff.Length, reminder)
            encodedText.Add(CByte(keyBuff(reminder) Xor AscW(text.Chars(i))))
        Next

        Return encodedText.ToArray(Type.GetType("System.Byte"))
    End Function

    'text decoder
    Private Function decode(ByVal keyBuff() As Byte, ByVal encodedText() As Byte) As String
        Dim i As Integer
        Dim count As Integer = encodedText.Length
        Dim result As Integer, reminder As Integer
        Dim decodedText As New String("")

        For i = 0 To count - 2
            result = Math.DivRem(i, keyBuff.Length, reminder)
            decodedText += Chr(keyBuff(reminder) Xor encodedText(i))
        Next

        Return decodedText
    End Function

    'this returns just numbers
    Public ReadOnly Property top10Results() As String()
        Get
            Dim i As Integer
            Dim values(10) As String

            If topResults.Count = 0 Then Return Nothing
            For i = 0 To 9
                values(i) = topResults.Item(i)
            Next

            Return values
        End Get
    End Property

    'returns the whole table
    Public ReadOnly Property TopTable() As System.Collections.Specialized.NameValueCollection
        Get
            Return topResults
        End Get
    End Property
End Class
