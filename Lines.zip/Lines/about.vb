Public Class about
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents ButtonOK As System.Windows.Forms.Button
    Friend WithEvents LabelLine1 As System.Windows.Forms.Label
    Friend WithEvents LabelLine2 As System.Windows.Forms.Label
    Friend WithEvents LabelLine3 As System.Windows.Forms.Label
    Friend WithEvents Ball1 As System.Windows.Forms.Label
    Friend WithEvents Ball3 As System.Windows.Forms.Label
    Friend WithEvents Ball2 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(about))
        Me.ButtonOK = New System.Windows.Forms.Button()
        Me.LabelLine1 = New System.Windows.Forms.Label()
        Me.LabelLine2 = New System.Windows.Forms.Label()
        Me.LabelLine3 = New System.Windows.Forms.Label()
        Me.Ball1 = New System.Windows.Forms.Label()
        Me.Ball3 = New System.Windows.Forms.Label()
        Me.Ball2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'ButtonOK
        '
        Me.ButtonOK.Location = New System.Drawing.Point(40, 88)
        Me.ButtonOK.Name = "ButtonOK"
        Me.ButtonOK.Size = New System.Drawing.Size(75, 23)
        Me.ButtonOK.TabIndex = 0
        Me.ButtonOK.Text = "OK"
        '
        'LabelLine1
        '
        Me.LabelLine1.Location = New System.Drawing.Point(112, 8)
        Me.LabelLine1.Name = "LabelLine1"
        Me.LabelLine1.Size = New System.Drawing.Size(144, 23)
        Me.LabelLine1.TabIndex = 1
        Me.LabelLine1.Text = "Circles     v2.0"
        '
        'LabelLine2
        '
        Me.LabelLine2.Location = New System.Drawing.Point(112, 32)
        Me.LabelLine2.Name = "LabelLine2"
        Me.LabelLine2.Size = New System.Drawing.Size(144, 30)
        Me.LabelLine2.TabIndex = 2
        Me.LabelLine2.Text = "Author: Sasha Matronitsky, Aryan Negi" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'LabelLine3
        '
        Me.LabelLine3.Location = New System.Drawing.Point(121, 71)
        Me.LabelLine3.Name = "LabelLine3"
        Me.LabelLine3.Size = New System.Drawing.Size(100, 23)
        Me.LabelLine3.TabIndex = 3
        Me.LabelLine3.Text = "VB.NET"
        '
        'Ball1
        '
        Me.Ball1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Ball1.Image = CType(resources.GetObject("Ball1.Image"), System.Drawing.Image)
        Me.Ball1.Location = New System.Drawing.Point(8, 24)
        Me.Ball1.Name = "Ball1"
        Me.Ball1.Size = New System.Drawing.Size(31, 31)
        Me.Ball1.TabIndex = 102
        '
        'Ball3
        '
        Me.Ball3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Ball3.Image = CType(resources.GetObject("Ball3.Image"), System.Drawing.Image)
        Me.Ball3.Location = New System.Drawing.Point(72, 24)
        Me.Ball3.Name = "Ball3"
        Me.Ball3.Size = New System.Drawing.Size(31, 31)
        Me.Ball3.TabIndex = 104
        '
        'Ball2
        '
        Me.Ball2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Ball2.Image = CType(resources.GetObject("Ball2.Image"), System.Drawing.Image)
        Me.Ball2.Location = New System.Drawing.Point(40, 24)
        Me.Ball2.Name = "Ball2"
        Me.Ball2.Size = New System.Drawing.Size(31, 31)
        Me.Ball2.TabIndex = 103
        '
        'about
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(264, 126)
        Me.Controls.Add(Me.Ball1)
        Me.Controls.Add(Me.Ball2)
        Me.Controls.Add(Me.Ball3)
        Me.Controls.Add(Me.LabelLine3)
        Me.Controls.Add(Me.LabelLine2)
        Me.Controls.Add(Me.LabelLine1)
        Me.Controls.Add(Me.ButtonOK)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "about"
        Me.ShowInTaskbar = False
        Me.Text = "about"
        Me.TopMost = True
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub ButtonOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonOK.Click
        Me.Close()
    End Sub

End Class
