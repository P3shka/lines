
' Class:  StringTokenizer
' It was written due to the fact that
' .NET does not provide similar functionality


Public Class StringTokenizer
    'String tokenizer class
    Private text As String, iterator As Integer
    Private separator As String   'token separator
    Private stokens() As String 'array of tokens
    Public Sub New(ByVal text As String, ByVal separator As Char)
        Me.text = text
        Me.separator = separator
        setSeparator(separator)
    End Sub
    Private Sub setSeparator(ByVal sp As Char)
        stokens = Split(text, separator)
        iterator = -1
    End Sub
    Public Function nextToken() As String
        Dim tok As String
        If iterator < UBound(stokens) Then
            iterator = iterator + 1
            tok = stokens(iterator)
        Else
            tok = ""
        End If
        Return tok    'return token
    End Function
    Public ReadOnly Property isTokenAvailable() As Boolean
        Get
            If iterator < UBound(stokens) Then
                Return True
            Else
                Return False
            End If
        End Get
    End Property

End Class
