Imports System
Imports System.Threading
Imports System.Windows.Forms.Form

Public Class mainForm
    Inherits System.Windows.Forms.Form

    Private ReadOnly NUM_BALLS_TO_PLACE As Integer = 3
    Public Const NUM_OF_FIELDS As Integer = 64        'field size
    Public Const SIZE_OF_ROW As Integer = 8           'size of a row
    Public Const SIZE_OF_LINE As Integer = 5          'min colleted line to be erased
    Public Const EMPTY_SPACE As Integer = -1
    Public Const NO_MOVE_IMAGE_INDEX As Integer = 5
    Private ReadOnly SELECTED_COLOR As System.Drawing.Color = System.Drawing.Color.BlueViolet
    Private prevStatus(NUM_OF_FIELDS - 1) As Integer
    Private prevScore As String
    Private score As Integer = 0
    Private source As Label = Nothing
    Private finder As pathFinder
    Private fields(NUM_OF_FIELDS - 1) As Integer      'reflect current situation on field. Consist of colors
    Private availableFields As ArrayList              'array of unoccupied fields
    Private top10 As New BestResults
    Friend WithEvents MenuItem2 As MenuItem
    Private color As New Color


#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        placeBallsOnField(True)

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    Public Shared Sub Main()
        Application.Run(New mainForm)
    End Sub
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem6 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem8 As System.Windows.Forms.MenuItem
    Friend WithEvents MainMenu As System.Windows.Forms.MainMenu
    Friend WithEvents ImageList As System.Windows.Forms.ImageList
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Field1 As System.Windows.Forms.Label
    Friend WithEvents Field2 As System.Windows.Forms.Label
    Friend WithEvents Field3 As System.Windows.Forms.Label
    Friend WithEvents Field4 As System.Windows.Forms.Label
    Friend WithEvents Field5 As System.Windows.Forms.Label
    Friend WithEvents Field6 As System.Windows.Forms.Label
    Friend WithEvents Field63 As System.Windows.Forms.Label
    Friend WithEvents Field62 As System.Windows.Forms.Label
    Friend WithEvents Field61 As System.Windows.Forms.Label
    Friend WithEvents Field60 As System.Windows.Forms.Label
    Friend WithEvents Field59 As System.Windows.Forms.Label
    Friend WithEvents Field58 As System.Windows.Forms.Label
    Friend WithEvents Field57 As System.Windows.Forms.Label
    Friend WithEvents Field56 As System.Windows.Forms.Label
    Friend WithEvents Field55 As System.Windows.Forms.Label
    Friend WithEvents Field54 As System.Windows.Forms.Label
    Friend WithEvents Field53 As System.Windows.Forms.Label
    Friend WithEvents Field52 As System.Windows.Forms.Label
    Friend WithEvents Field51 As System.Windows.Forms.Label
    Friend WithEvents Field50 As System.Windows.Forms.Label
    Friend WithEvents Field49 As System.Windows.Forms.Label
    Friend WithEvents Field48 As System.Windows.Forms.Label
    Friend WithEvents Field47 As System.Windows.Forms.Label
    Friend WithEvents Field46 As System.Windows.Forms.Label
    Friend WithEvents Field45 As System.Windows.Forms.Label
    Friend WithEvents Field44 As System.Windows.Forms.Label
    Friend WithEvents Field43 As System.Windows.Forms.Label
    Friend WithEvents Field42 As System.Windows.Forms.Label
    Friend WithEvents Field41 As System.Windows.Forms.Label
    Friend WithEvents Field40 As System.Windows.Forms.Label
    Friend WithEvents Field39 As System.Windows.Forms.Label
    Friend WithEvents Field38 As System.Windows.Forms.Label
    Friend WithEvents Field37 As System.Windows.Forms.Label
    Friend WithEvents Field36 As System.Windows.Forms.Label
    Friend WithEvents Field35 As System.Windows.Forms.Label
    Friend WithEvents Field34 As System.Windows.Forms.Label
    Friend WithEvents Field33 As System.Windows.Forms.Label
    Friend WithEvents Field32 As System.Windows.Forms.Label
    Friend WithEvents Field31 As System.Windows.Forms.Label
    Friend WithEvents Field30 As System.Windows.Forms.Label
    Friend WithEvents Field29 As System.Windows.Forms.Label
    Friend WithEvents Field28 As System.Windows.Forms.Label
    Friend WithEvents Field27 As System.Windows.Forms.Label
    Friend WithEvents Field26 As System.Windows.Forms.Label
    Friend WithEvents Field25 As System.Windows.Forms.Label
    Friend WithEvents Field24 As System.Windows.Forms.Label
    Friend WithEvents Field23 As System.Windows.Forms.Label
    Friend WithEvents Field22 As System.Windows.Forms.Label
    Friend WithEvents Field21 As System.Windows.Forms.Label
    Friend WithEvents Field20 As System.Windows.Forms.Label
    Friend WithEvents Field19 As System.Windows.Forms.Label
    Friend WithEvents Field18 As System.Windows.Forms.Label
    Friend WithEvents Field17 As System.Windows.Forms.Label
    Friend WithEvents Field16 As System.Windows.Forms.Label
    Friend WithEvents Field15 As System.Windows.Forms.Label
    Friend WithEvents Field14 As System.Windows.Forms.Label
    Friend WithEvents Field13 As System.Windows.Forms.Label
    Friend WithEvents Field12 As System.Windows.Forms.Label
    Friend WithEvents Field11 As System.Windows.Forms.Label
    Friend WithEvents Field10 As System.Windows.Forms.Label
    Friend WithEvents Field64 As System.Windows.Forms.Label
    Friend WithEvents Next1 As System.Windows.Forms.Label
    Friend WithEvents Next2 As System.Windows.Forms.Label
    Friend WithEvents Next3 As System.Windows.Forms.Label
    Friend WithEvents nextLabel As System.Windows.Forms.Label
    Friend WithEvents scoreTextBox As System.Windows.Forms.TextBox
    Friend WithEvents scoreLabel As System.Windows.Forms.Label
    Friend WithEvents MenuItemNew As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItemLoad As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItemSave As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItemBestResults As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItemExit As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItemStepBack As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItemAbout As System.Windows.Forms.MenuItem
    Friend WithEvents Field9 As System.Windows.Forms.Label
    Friend WithEvents Field8 As System.Windows.Forms.Label
    Friend WithEvents Field7 As System.Windows.Forms.Label
    Friend WithEvents topScoreTextBox As System.Windows.Forms.TextBox
    Friend WithEvents topScoreLabel As System.Windows.Forms.Label
    Friend WithEvents OpenFileDialog As System.Windows.Forms.OpenFileDialog
    Friend WithEvents SaveFileDialog As System.Windows.Forms.SaveFileDialog
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(mainForm))
        Me.MainMenu = New System.Windows.Forms.MainMenu(Me.components)
        Me.MenuItem1 = New System.Windows.Forms.MenuItem()
        Me.MenuItemNew = New System.Windows.Forms.MenuItem()
        Me.MenuItemLoad = New System.Windows.Forms.MenuItem()
        Me.MenuItemSave = New System.Windows.Forms.MenuItem()
        Me.MenuItemBestResults = New System.Windows.Forms.MenuItem()
        Me.MenuItemExit = New System.Windows.Forms.MenuItem()
        Me.MenuItem6 = New System.Windows.Forms.MenuItem()
        Me.MenuItemStepBack = New System.Windows.Forms.MenuItem()
        Me.MenuItem8 = New System.Windows.Forms.MenuItem()
        Me.MenuItemAbout = New System.Windows.Forms.MenuItem()
        Me.ImageList = New System.Windows.Forms.ImageList(Me.components)
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Field1 = New System.Windows.Forms.Label()
        Me.Field2 = New System.Windows.Forms.Label()
        Me.Field3 = New System.Windows.Forms.Label()
        Me.Field4 = New System.Windows.Forms.Label()
        Me.Field5 = New System.Windows.Forms.Label()
        Me.Field6 = New System.Windows.Forms.Label()
        Me.Field7 = New System.Windows.Forms.Label()
        Me.Field8 = New System.Windows.Forms.Label()
        Me.Field9 = New System.Windows.Forms.Label()
        Me.Field10 = New System.Windows.Forms.Label()
        Me.Field11 = New System.Windows.Forms.Label()
        Me.Field12 = New System.Windows.Forms.Label()
        Me.Field13 = New System.Windows.Forms.Label()
        Me.Field14 = New System.Windows.Forms.Label()
        Me.Field15 = New System.Windows.Forms.Label()
        Me.Field16 = New System.Windows.Forms.Label()
        Me.Field17 = New System.Windows.Forms.Label()
        Me.Field18 = New System.Windows.Forms.Label()
        Me.Field19 = New System.Windows.Forms.Label()
        Me.Field20 = New System.Windows.Forms.Label()
        Me.Field21 = New System.Windows.Forms.Label()
        Me.Field22 = New System.Windows.Forms.Label()
        Me.Field23 = New System.Windows.Forms.Label()
        Me.Field24 = New System.Windows.Forms.Label()
        Me.Field25 = New System.Windows.Forms.Label()
        Me.Field26 = New System.Windows.Forms.Label()
        Me.Field27 = New System.Windows.Forms.Label()
        Me.Field28 = New System.Windows.Forms.Label()
        Me.Field29 = New System.Windows.Forms.Label()
        Me.Field30 = New System.Windows.Forms.Label()
        Me.Field31 = New System.Windows.Forms.Label()
        Me.Field32 = New System.Windows.Forms.Label()
        Me.Field33 = New System.Windows.Forms.Label()
        Me.Field34 = New System.Windows.Forms.Label()
        Me.Field35 = New System.Windows.Forms.Label()
        Me.Field36 = New System.Windows.Forms.Label()
        Me.Field37 = New System.Windows.Forms.Label()
        Me.Field38 = New System.Windows.Forms.Label()
        Me.Field39 = New System.Windows.Forms.Label()
        Me.Field40 = New System.Windows.Forms.Label()
        Me.Field41 = New System.Windows.Forms.Label()
        Me.Field42 = New System.Windows.Forms.Label()
        Me.Field43 = New System.Windows.Forms.Label()
        Me.Field44 = New System.Windows.Forms.Label()
        Me.Field45 = New System.Windows.Forms.Label()
        Me.Field46 = New System.Windows.Forms.Label()
        Me.Field47 = New System.Windows.Forms.Label()
        Me.Field48 = New System.Windows.Forms.Label()
        Me.Field49 = New System.Windows.Forms.Label()
        Me.Field50 = New System.Windows.Forms.Label()
        Me.Field51 = New System.Windows.Forms.Label()
        Me.Field52 = New System.Windows.Forms.Label()
        Me.Field53 = New System.Windows.Forms.Label()
        Me.Field54 = New System.Windows.Forms.Label()
        Me.Field55 = New System.Windows.Forms.Label()
        Me.Field56 = New System.Windows.Forms.Label()
        Me.Field57 = New System.Windows.Forms.Label()
        Me.Field58 = New System.Windows.Forms.Label()
        Me.Field59 = New System.Windows.Forms.Label()
        Me.Field60 = New System.Windows.Forms.Label()
        Me.Field61 = New System.Windows.Forms.Label()
        Me.Field62 = New System.Windows.Forms.Label()
        Me.Field63 = New System.Windows.Forms.Label()
        Me.Field64 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.topScoreTextBox = New System.Windows.Forms.TextBox()
        Me.topScoreLabel = New System.Windows.Forms.Label()
        Me.Next1 = New System.Windows.Forms.Label()
        Me.Next2 = New System.Windows.Forms.Label()
        Me.Next3 = New System.Windows.Forms.Label()
        Me.nextLabel = New System.Windows.Forms.Label()
        Me.scoreTextBox = New System.Windows.Forms.TextBox()
        Me.scoreLabel = New System.Windows.Forms.Label()
        Me.OpenFileDialog = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog = New System.Windows.Forms.SaveFileDialog()
        Me.MenuItem2 = New System.Windows.Forms.MenuItem()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'MainMenu
        '
        Me.MainMenu.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1, Me.MenuItem6, Me.MenuItem8})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItemNew, Me.MenuItemLoad, Me.MenuItemSave, Me.MenuItemBestResults, Me.MenuItemExit})
        Me.MenuItem1.Text = "Game"
        '
        'MenuItemNew
        '
        Me.MenuItemNew.Index = 0
        Me.MenuItemNew.Text = "New"
        '
        'MenuItemLoad
        '
        Me.MenuItemLoad.Index = 1
        Me.MenuItemLoad.Text = "Load..."
        '
        'MenuItemSave
        '
        Me.MenuItemSave.Index = 2
        Me.MenuItemSave.Text = "Save..."
        '
        'MenuItemBestResults
        '
        Me.MenuItemBestResults.Index = 3
        Me.MenuItemBestResults.Text = "Best Results"
        '
        'MenuItemExit
        '
        Me.MenuItemExit.Index = 4
        Me.MenuItemExit.Text = "Exit"
        '
        'MenuItem6
        '
        Me.MenuItem6.Index = 1
        Me.MenuItem6.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItemStepBack})
        Me.MenuItem6.Text = "Step"
        '
        'MenuItemStepBack
        '
        Me.MenuItemStepBack.Index = 0
        Me.MenuItemStepBack.Text = "Back"
        '
        'MenuItem8
        '
        Me.MenuItem8.Index = 2
        Me.MenuItem8.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItemAbout, Me.MenuItem2})
        Me.MenuItem8.Text = "Help"
        '
        'MenuItemAbout
        '
        Me.MenuItemAbout.Index = 0
        Me.MenuItemAbout.Text = "About..."
        '
        'ImageList
        '
        Me.ImageList.ImageStream = CType(resources.GetObject("ImageList.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList.Images.SetKeyName(0, "")
        Me.ImageList.Images.SetKeyName(1, "")
        Me.ImageList.Images.SetKeyName(2, "")
        Me.ImageList.Images.SetKeyName(3, "")
        Me.ImageList.Images.SetKeyName(4, "")
        Me.ImageList.Images.SetKeyName(5, "")
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.Field1)
        Me.Panel1.Controls.Add(Me.Field2)
        Me.Panel1.Controls.Add(Me.Field3)
        Me.Panel1.Controls.Add(Me.Field4)
        Me.Panel1.Controls.Add(Me.Field5)
        Me.Panel1.Controls.Add(Me.Field6)
        Me.Panel1.Controls.Add(Me.Field7)
        Me.Panel1.Controls.Add(Me.Field8)
        Me.Panel1.Controls.Add(Me.Field9)
        Me.Panel1.Controls.Add(Me.Field10)
        Me.Panel1.Controls.Add(Me.Field11)
        Me.Panel1.Controls.Add(Me.Field12)
        Me.Panel1.Controls.Add(Me.Field13)
        Me.Panel1.Controls.Add(Me.Field14)
        Me.Panel1.Controls.Add(Me.Field15)
        Me.Panel1.Controls.Add(Me.Field16)
        Me.Panel1.Controls.Add(Me.Field17)
        Me.Panel1.Controls.Add(Me.Field18)
        Me.Panel1.Controls.Add(Me.Field19)
        Me.Panel1.Controls.Add(Me.Field20)
        Me.Panel1.Controls.Add(Me.Field21)
        Me.Panel1.Controls.Add(Me.Field22)
        Me.Panel1.Controls.Add(Me.Field23)
        Me.Panel1.Controls.Add(Me.Field24)
        Me.Panel1.Controls.Add(Me.Field25)
        Me.Panel1.Controls.Add(Me.Field26)
        Me.Panel1.Controls.Add(Me.Field27)
        Me.Panel1.Controls.Add(Me.Field28)
        Me.Panel1.Controls.Add(Me.Field29)
        Me.Panel1.Controls.Add(Me.Field30)
        Me.Panel1.Controls.Add(Me.Field31)
        Me.Panel1.Controls.Add(Me.Field32)
        Me.Panel1.Controls.Add(Me.Field33)
        Me.Panel1.Controls.Add(Me.Field34)
        Me.Panel1.Controls.Add(Me.Field35)
        Me.Panel1.Controls.Add(Me.Field36)
        Me.Panel1.Controls.Add(Me.Field37)
        Me.Panel1.Controls.Add(Me.Field38)
        Me.Panel1.Controls.Add(Me.Field39)
        Me.Panel1.Controls.Add(Me.Field40)
        Me.Panel1.Controls.Add(Me.Field41)
        Me.Panel1.Controls.Add(Me.Field42)
        Me.Panel1.Controls.Add(Me.Field43)
        Me.Panel1.Controls.Add(Me.Field44)
        Me.Panel1.Controls.Add(Me.Field45)
        Me.Panel1.Controls.Add(Me.Field46)
        Me.Panel1.Controls.Add(Me.Field47)
        Me.Panel1.Controls.Add(Me.Field48)
        Me.Panel1.Controls.Add(Me.Field49)
        Me.Panel1.Controls.Add(Me.Field50)
        Me.Panel1.Controls.Add(Me.Field51)
        Me.Panel1.Controls.Add(Me.Field52)
        Me.Panel1.Controls.Add(Me.Field53)
        Me.Panel1.Controls.Add(Me.Field54)
        Me.Panel1.Controls.Add(Me.Field55)
        Me.Panel1.Controls.Add(Me.Field56)
        Me.Panel1.Controls.Add(Me.Field57)
        Me.Panel1.Controls.Add(Me.Field58)
        Me.Panel1.Controls.Add(Me.Field59)
        Me.Panel1.Controls.Add(Me.Field60)
        Me.Panel1.Controls.Add(Me.Field61)
        Me.Panel1.Controls.Add(Me.Field62)
        Me.Panel1.Controls.Add(Me.Field63)
        Me.Panel1.Controls.Add(Me.Field64)
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(258, 258)
        Me.Panel1.TabIndex = 0
        '
        'Field1
        '
        Me.Field1.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field1.ImageList = Me.ImageList
        Me.Field1.Location = New System.Drawing.Point(0, 0)
        Me.Field1.Name = "Field1"
        Me.Field1.Size = New System.Drawing.Size(31, 31)
        Me.Field1.TabIndex = 0
        '
        'Field2
        '
        Me.Field2.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field2.ImageList = Me.ImageList
        Me.Field2.Location = New System.Drawing.Point(32, 0)
        Me.Field2.Name = "Field2"
        Me.Field2.Size = New System.Drawing.Size(31, 31)
        Me.Field2.TabIndex = 1
        '
        'Field3
        '
        Me.Field3.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field3.ImageList = Me.ImageList
        Me.Field3.Location = New System.Drawing.Point(64, 0)
        Me.Field3.Name = "Field3"
        Me.Field3.Size = New System.Drawing.Size(31, 31)
        Me.Field3.TabIndex = 2
        '
        'Field4
        '
        Me.Field4.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field4.ImageList = Me.ImageList
        Me.Field4.Location = New System.Drawing.Point(96, 0)
        Me.Field4.Name = "Field4"
        Me.Field4.Size = New System.Drawing.Size(31, 31)
        Me.Field4.TabIndex = 3
        '
        'Field5
        '
        Me.Field5.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field5.ImageList = Me.ImageList
        Me.Field5.Location = New System.Drawing.Point(128, 0)
        Me.Field5.Name = "Field5"
        Me.Field5.Size = New System.Drawing.Size(31, 31)
        Me.Field5.TabIndex = 4
        '
        'Field6
        '
        Me.Field6.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field6.ImageList = Me.ImageList
        Me.Field6.Location = New System.Drawing.Point(160, 0)
        Me.Field6.Name = "Field6"
        Me.Field6.Size = New System.Drawing.Size(31, 31)
        Me.Field6.TabIndex = 5
        '
        'Field7
        '
        Me.Field7.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field7.ImageList = Me.ImageList
        Me.Field7.Location = New System.Drawing.Point(192, 0)
        Me.Field7.Name = "Field7"
        Me.Field7.Size = New System.Drawing.Size(31, 31)
        Me.Field7.TabIndex = 6
        '
        'Field8
        '
        Me.Field8.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field8.ImageList = Me.ImageList
        Me.Field8.Location = New System.Drawing.Point(224, 0)
        Me.Field8.Name = "Field8"
        Me.Field8.Size = New System.Drawing.Size(31, 31)
        Me.Field8.TabIndex = 7
        '
        'Field9
        '
        Me.Field9.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field9.ImageList = Me.ImageList
        Me.Field9.Location = New System.Drawing.Point(0, 32)
        Me.Field9.Name = "Field9"
        Me.Field9.Size = New System.Drawing.Size(31, 31)
        Me.Field9.TabIndex = 8
        '
        'Field10
        '
        Me.Field10.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field10.ImageList = Me.ImageList
        Me.Field10.Location = New System.Drawing.Point(32, 32)
        Me.Field10.Name = "Field10"
        Me.Field10.Size = New System.Drawing.Size(31, 31)
        Me.Field10.TabIndex = 9
        '
        'Field11
        '
        Me.Field11.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field11.ImageList = Me.ImageList
        Me.Field11.Location = New System.Drawing.Point(64, 32)
        Me.Field11.Name = "Field11"
        Me.Field11.Size = New System.Drawing.Size(31, 31)
        Me.Field11.TabIndex = 10
        '
        'Field12
        '
        Me.Field12.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field12.ImageList = Me.ImageList
        Me.Field12.Location = New System.Drawing.Point(96, 32)
        Me.Field12.Name = "Field12"
        Me.Field12.Size = New System.Drawing.Size(31, 31)
        Me.Field12.TabIndex = 11
        '
        'Field13
        '
        Me.Field13.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field13.ImageList = Me.ImageList
        Me.Field13.Location = New System.Drawing.Point(128, 32)
        Me.Field13.Name = "Field13"
        Me.Field13.Size = New System.Drawing.Size(31, 31)
        Me.Field13.TabIndex = 12
        '
        'Field14
        '
        Me.Field14.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field14.ImageList = Me.ImageList
        Me.Field14.Location = New System.Drawing.Point(160, 32)
        Me.Field14.Name = "Field14"
        Me.Field14.Size = New System.Drawing.Size(31, 31)
        Me.Field14.TabIndex = 13
        '
        'Field15
        '
        Me.Field15.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field15.ImageList = Me.ImageList
        Me.Field15.Location = New System.Drawing.Point(192, 32)
        Me.Field15.Name = "Field15"
        Me.Field15.Size = New System.Drawing.Size(31, 31)
        Me.Field15.TabIndex = 14
        '
        'Field16
        '
        Me.Field16.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field16.ImageList = Me.ImageList
        Me.Field16.Location = New System.Drawing.Point(224, 32)
        Me.Field16.Name = "Field16"
        Me.Field16.Size = New System.Drawing.Size(31, 31)
        Me.Field16.TabIndex = 15
        '
        'Field17
        '
        Me.Field17.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field17.ImageList = Me.ImageList
        Me.Field17.Location = New System.Drawing.Point(0, 64)
        Me.Field17.Name = "Field17"
        Me.Field17.Size = New System.Drawing.Size(31, 31)
        Me.Field17.TabIndex = 16
        '
        'Field18
        '
        Me.Field18.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field18.ImageList = Me.ImageList
        Me.Field18.Location = New System.Drawing.Point(32, 64)
        Me.Field18.Name = "Field18"
        Me.Field18.Size = New System.Drawing.Size(31, 31)
        Me.Field18.TabIndex = 17
        '
        'Field19
        '
        Me.Field19.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field19.ImageList = Me.ImageList
        Me.Field19.Location = New System.Drawing.Point(64, 64)
        Me.Field19.Name = "Field19"
        Me.Field19.Size = New System.Drawing.Size(31, 31)
        Me.Field19.TabIndex = 18
        '
        'Field20
        '
        Me.Field20.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field20.ImageList = Me.ImageList
        Me.Field20.Location = New System.Drawing.Point(96, 64)
        Me.Field20.Name = "Field20"
        Me.Field20.Size = New System.Drawing.Size(31, 31)
        Me.Field20.TabIndex = 19
        '
        'Field21
        '
        Me.Field21.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field21.ImageList = Me.ImageList
        Me.Field21.Location = New System.Drawing.Point(128, 64)
        Me.Field21.Name = "Field21"
        Me.Field21.Size = New System.Drawing.Size(31, 31)
        Me.Field21.TabIndex = 20
        '
        'Field22
        '
        Me.Field22.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field22.ImageList = Me.ImageList
        Me.Field22.Location = New System.Drawing.Point(160, 64)
        Me.Field22.Name = "Field22"
        Me.Field22.Size = New System.Drawing.Size(31, 31)
        Me.Field22.TabIndex = 21
        '
        'Field23
        '
        Me.Field23.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field23.ImageList = Me.ImageList
        Me.Field23.Location = New System.Drawing.Point(192, 64)
        Me.Field23.Name = "Field23"
        Me.Field23.Size = New System.Drawing.Size(31, 31)
        Me.Field23.TabIndex = 22
        '
        'Field24
        '
        Me.Field24.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field24.ImageList = Me.ImageList
        Me.Field24.Location = New System.Drawing.Point(224, 64)
        Me.Field24.Name = "Field24"
        Me.Field24.Size = New System.Drawing.Size(31, 31)
        Me.Field24.TabIndex = 23
        '
        'Field25
        '
        Me.Field25.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field25.ImageList = Me.ImageList
        Me.Field25.Location = New System.Drawing.Point(0, 96)
        Me.Field25.Name = "Field25"
        Me.Field25.Size = New System.Drawing.Size(31, 31)
        Me.Field25.TabIndex = 24
        '
        'Field26
        '
        Me.Field26.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field26.ImageList = Me.ImageList
        Me.Field26.Location = New System.Drawing.Point(32, 96)
        Me.Field26.Name = "Field26"
        Me.Field26.Size = New System.Drawing.Size(31, 31)
        Me.Field26.TabIndex = 25
        '
        'Field27
        '
        Me.Field27.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field27.ImageList = Me.ImageList
        Me.Field27.Location = New System.Drawing.Point(64, 96)
        Me.Field27.Name = "Field27"
        Me.Field27.Size = New System.Drawing.Size(31, 31)
        Me.Field27.TabIndex = 26
        '
        'Field28
        '
        Me.Field28.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field28.ImageList = Me.ImageList
        Me.Field28.Location = New System.Drawing.Point(96, 96)
        Me.Field28.Name = "Field28"
        Me.Field28.Size = New System.Drawing.Size(31, 31)
        Me.Field28.TabIndex = 27
        '
        'Field29
        '
        Me.Field29.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field29.ImageList = Me.ImageList
        Me.Field29.Location = New System.Drawing.Point(128, 96)
        Me.Field29.Name = "Field29"
        Me.Field29.Size = New System.Drawing.Size(31, 31)
        Me.Field29.TabIndex = 28
        '
        'Field30
        '
        Me.Field30.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field30.ImageList = Me.ImageList
        Me.Field30.Location = New System.Drawing.Point(160, 96)
        Me.Field30.Name = "Field30"
        Me.Field30.Size = New System.Drawing.Size(31, 31)
        Me.Field30.TabIndex = 29
        '
        'Field31
        '
        Me.Field31.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field31.ImageList = Me.ImageList
        Me.Field31.Location = New System.Drawing.Point(192, 96)
        Me.Field31.Name = "Field31"
        Me.Field31.Size = New System.Drawing.Size(31, 31)
        Me.Field31.TabIndex = 30
        '
        'Field32
        '
        Me.Field32.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field32.ImageList = Me.ImageList
        Me.Field32.Location = New System.Drawing.Point(224, 96)
        Me.Field32.Name = "Field32"
        Me.Field32.Size = New System.Drawing.Size(31, 31)
        Me.Field32.TabIndex = 31
        '
        'Field33
        '
        Me.Field33.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field33.ImageList = Me.ImageList
        Me.Field33.Location = New System.Drawing.Point(0, 128)
        Me.Field33.Name = "Field33"
        Me.Field33.Size = New System.Drawing.Size(31, 31)
        Me.Field33.TabIndex = 32
        '
        'Field34
        '
        Me.Field34.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field34.ImageList = Me.ImageList
        Me.Field34.Location = New System.Drawing.Point(32, 128)
        Me.Field34.Name = "Field34"
        Me.Field34.Size = New System.Drawing.Size(31, 31)
        Me.Field34.TabIndex = 33
        '
        'Field35
        '
        Me.Field35.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field35.ImageList = Me.ImageList
        Me.Field35.Location = New System.Drawing.Point(64, 128)
        Me.Field35.Name = "Field35"
        Me.Field35.Size = New System.Drawing.Size(31, 31)
        Me.Field35.TabIndex = 34
        '
        'Field36
        '
        Me.Field36.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field36.ImageList = Me.ImageList
        Me.Field36.Location = New System.Drawing.Point(96, 128)
        Me.Field36.Name = "Field36"
        Me.Field36.Size = New System.Drawing.Size(31, 31)
        Me.Field36.TabIndex = 35
        '
        'Field37
        '
        Me.Field37.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field37.ImageList = Me.ImageList
        Me.Field37.Location = New System.Drawing.Point(128, 128)
        Me.Field37.Name = "Field37"
        Me.Field37.Size = New System.Drawing.Size(31, 31)
        Me.Field37.TabIndex = 36
        '
        'Field38
        '
        Me.Field38.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field38.ImageList = Me.ImageList
        Me.Field38.Location = New System.Drawing.Point(160, 128)
        Me.Field38.Name = "Field38"
        Me.Field38.Size = New System.Drawing.Size(31, 31)
        Me.Field38.TabIndex = 37
        '
        'Field39
        '
        Me.Field39.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field39.ImageList = Me.ImageList
        Me.Field39.Location = New System.Drawing.Point(192, 128)
        Me.Field39.Name = "Field39"
        Me.Field39.Size = New System.Drawing.Size(31, 31)
        Me.Field39.TabIndex = 38
        '
        'Field40
        '
        Me.Field40.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field40.ImageList = Me.ImageList
        Me.Field40.Location = New System.Drawing.Point(224, 128)
        Me.Field40.Name = "Field40"
        Me.Field40.Size = New System.Drawing.Size(31, 31)
        Me.Field40.TabIndex = 39
        '
        'Field41
        '
        Me.Field41.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field41.ImageList = Me.ImageList
        Me.Field41.Location = New System.Drawing.Point(0, 160)
        Me.Field41.Name = "Field41"
        Me.Field41.Size = New System.Drawing.Size(31, 31)
        Me.Field41.TabIndex = 40
        '
        'Field42
        '
        Me.Field42.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field42.ImageList = Me.ImageList
        Me.Field42.Location = New System.Drawing.Point(32, 160)
        Me.Field42.Name = "Field42"
        Me.Field42.Size = New System.Drawing.Size(31, 31)
        Me.Field42.TabIndex = 41
        '
        'Field43
        '
        Me.Field43.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field43.ImageList = Me.ImageList
        Me.Field43.Location = New System.Drawing.Point(64, 160)
        Me.Field43.Name = "Field43"
        Me.Field43.Size = New System.Drawing.Size(31, 31)
        Me.Field43.TabIndex = 42
        '
        'Field44
        '
        Me.Field44.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field44.ImageList = Me.ImageList
        Me.Field44.Location = New System.Drawing.Point(96, 160)
        Me.Field44.Name = "Field44"
        Me.Field44.Size = New System.Drawing.Size(31, 31)
        Me.Field44.TabIndex = 43
        '
        'Field45
        '
        Me.Field45.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field45.ImageList = Me.ImageList
        Me.Field45.Location = New System.Drawing.Point(128, 160)
        Me.Field45.Name = "Field45"
        Me.Field45.Size = New System.Drawing.Size(31, 31)
        Me.Field45.TabIndex = 44
        '
        'Field46
        '
        Me.Field46.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field46.ImageList = Me.ImageList
        Me.Field46.Location = New System.Drawing.Point(160, 160)
        Me.Field46.Name = "Field46"
        Me.Field46.Size = New System.Drawing.Size(31, 31)
        Me.Field46.TabIndex = 45
        '
        'Field47
        '
        Me.Field47.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field47.ImageList = Me.ImageList
        Me.Field47.Location = New System.Drawing.Point(192, 160)
        Me.Field47.Name = "Field47"
        Me.Field47.Size = New System.Drawing.Size(31, 31)
        Me.Field47.TabIndex = 46
        '
        'Field48
        '
        Me.Field48.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field48.ImageList = Me.ImageList
        Me.Field48.Location = New System.Drawing.Point(224, 160)
        Me.Field48.Name = "Field48"
        Me.Field48.Size = New System.Drawing.Size(31, 31)
        Me.Field48.TabIndex = 47
        '
        'Field49
        '
        Me.Field49.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field49.ImageList = Me.ImageList
        Me.Field49.Location = New System.Drawing.Point(0, 192)
        Me.Field49.Name = "Field49"
        Me.Field49.Size = New System.Drawing.Size(31, 31)
        Me.Field49.TabIndex = 48
        '
        'Field50
        '
        Me.Field50.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field50.ImageList = Me.ImageList
        Me.Field50.Location = New System.Drawing.Point(32, 192)
        Me.Field50.Name = "Field50"
        Me.Field50.Size = New System.Drawing.Size(31, 31)
        Me.Field50.TabIndex = 49
        '
        'Field51
        '
        Me.Field51.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field51.ImageList = Me.ImageList
        Me.Field51.Location = New System.Drawing.Point(64, 192)
        Me.Field51.Name = "Field51"
        Me.Field51.Size = New System.Drawing.Size(31, 31)
        Me.Field51.TabIndex = 50
        '
        'Field52
        '
        Me.Field52.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field52.ImageList = Me.ImageList
        Me.Field52.Location = New System.Drawing.Point(96, 192)
        Me.Field52.Name = "Field52"
        Me.Field52.Size = New System.Drawing.Size(31, 31)
        Me.Field52.TabIndex = 51
        '
        'Field53
        '
        Me.Field53.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field53.ImageList = Me.ImageList
        Me.Field53.Location = New System.Drawing.Point(128, 192)
        Me.Field53.Name = "Field53"
        Me.Field53.Size = New System.Drawing.Size(31, 31)
        Me.Field53.TabIndex = 52
        '
        'Field54
        '
        Me.Field54.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field54.ImageList = Me.ImageList
        Me.Field54.Location = New System.Drawing.Point(160, 192)
        Me.Field54.Name = "Field54"
        Me.Field54.Size = New System.Drawing.Size(31, 31)
        Me.Field54.TabIndex = 53
        '
        'Field55
        '
        Me.Field55.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field55.ImageList = Me.ImageList
        Me.Field55.Location = New System.Drawing.Point(192, 192)
        Me.Field55.Name = "Field55"
        Me.Field55.Size = New System.Drawing.Size(31, 31)
        Me.Field55.TabIndex = 54
        '
        'Field56
        '
        Me.Field56.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field56.ImageList = Me.ImageList
        Me.Field56.Location = New System.Drawing.Point(224, 192)
        Me.Field56.Name = "Field56"
        Me.Field56.Size = New System.Drawing.Size(31, 31)
        Me.Field56.TabIndex = 55
        '
        'Field57
        '
        Me.Field57.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field57.ImageList = Me.ImageList
        Me.Field57.Location = New System.Drawing.Point(0, 224)
        Me.Field57.Name = "Field57"
        Me.Field57.Size = New System.Drawing.Size(31, 31)
        Me.Field57.TabIndex = 56
        '
        'Field58
        '
        Me.Field58.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field58.ImageList = Me.ImageList
        Me.Field58.Location = New System.Drawing.Point(32, 224)
        Me.Field58.Name = "Field58"
        Me.Field58.Size = New System.Drawing.Size(31, 31)
        Me.Field58.TabIndex = 57
        '
        'Field59
        '
        Me.Field59.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field59.ImageList = Me.ImageList
        Me.Field59.Location = New System.Drawing.Point(64, 224)
        Me.Field59.Name = "Field59"
        Me.Field59.Size = New System.Drawing.Size(31, 31)
        Me.Field59.TabIndex = 58
        '
        'Field60
        '
        Me.Field60.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field60.ImageList = Me.ImageList
        Me.Field60.Location = New System.Drawing.Point(96, 224)
        Me.Field60.Name = "Field60"
        Me.Field60.Size = New System.Drawing.Size(31, 31)
        Me.Field60.TabIndex = 59
        '
        'Field61
        '
        Me.Field61.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field61.ImageList = Me.ImageList
        Me.Field61.Location = New System.Drawing.Point(128, 224)
        Me.Field61.Name = "Field61"
        Me.Field61.Size = New System.Drawing.Size(31, 31)
        Me.Field61.TabIndex = 60
        '
        'Field62
        '
        Me.Field62.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field62.ImageList = Me.ImageList
        Me.Field62.Location = New System.Drawing.Point(160, 224)
        Me.Field62.Name = "Field62"
        Me.Field62.Size = New System.Drawing.Size(31, 31)
        Me.Field62.TabIndex = 61
        '
        'Field63
        '
        Me.Field63.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field63.ImageList = Me.ImageList
        Me.Field63.Location = New System.Drawing.Point(192, 224)
        Me.Field63.Name = "Field63"
        Me.Field63.Size = New System.Drawing.Size(31, 31)
        Me.Field63.TabIndex = 62
        '
        'Field64
        '
        Me.Field64.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Field64.ImageList = Me.ImageList
        Me.Field64.Location = New System.Drawing.Point(224, 224)
        Me.Field64.Name = "Field64"
        Me.Field64.Size = New System.Drawing.Size(31, 31)
        Me.Field64.TabIndex = 63
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.topScoreTextBox)
        Me.Panel2.Controls.Add(Me.topScoreLabel)
        Me.Panel2.Controls.Add(Me.Next1)
        Me.Panel2.Controls.Add(Me.Next2)
        Me.Panel2.Controls.Add(Me.Next3)
        Me.Panel2.Controls.Add(Me.nextLabel)
        Me.Panel2.Controls.Add(Me.scoreTextBox)
        Me.Panel2.Controls.Add(Me.scoreLabel)
        Me.Panel2.Location = New System.Drawing.Point(256, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(112, 258)
        Me.Panel2.TabIndex = 1
        '
        'topScoreTextBox
        '
        Me.topScoreTextBox.Location = New System.Drawing.Point(25, 88)
        Me.topScoreTextBox.Name = "topScoreTextBox"
        Me.topScoreTextBox.ReadOnly = True
        Me.topScoreTextBox.Size = New System.Drawing.Size(59, 21)
        Me.topScoreTextBox.TabIndex = 102
        Me.topScoreTextBox.TabStop = False
        Me.topScoreTextBox.Text = "0"
        Me.topScoreTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.topScoreTextBox.WordWrap = False
        '
        'topScoreLabel
        '
        Me.topScoreLabel.Font = New System.Drawing.Font("Arial", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.topScoreLabel.Location = New System.Drawing.Point(16, 66)
        Me.topScoreLabel.Name = "topScoreLabel"
        Me.topScoreLabel.Size = New System.Drawing.Size(83, 23)
        Me.topScoreLabel.TabIndex = 101
        Me.topScoreLabel.Text = "Top Score"
        '
        'Next1
        '
        Me.Next1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Next1.ImageIndex = 1
        Me.Next1.ImageList = Me.ImageList
        Me.Next1.Location = New System.Drawing.Point(40, 144)
        Me.Next1.Name = "Next1"
        Me.Next1.Size = New System.Drawing.Size(32, 32)
        Me.Next1.TabIndex = 98
        '
        'Next2
        '
        Me.Next2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Next2.ImageIndex = 3
        Me.Next2.ImageList = Me.ImageList
        Me.Next2.Location = New System.Drawing.Point(40, 175)
        Me.Next2.Name = "Next2"
        Me.Next2.Size = New System.Drawing.Size(32, 32)
        Me.Next2.TabIndex = 99
        '
        'Next3
        '
        Me.Next3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Next3.ImageIndex = 2
        Me.Next3.ImageList = Me.ImageList
        Me.Next3.Location = New System.Drawing.Point(40, 205)
        Me.Next3.Name = "Next3"
        Me.Next3.Size = New System.Drawing.Size(32, 32)
        Me.Next3.TabIndex = 100
        '
        'nextLabel
        '
        Me.nextLabel.Font = New System.Drawing.Font("Arial", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.nextLabel.Location = New System.Drawing.Point(32, 120)
        Me.nextLabel.Name = "nextLabel"
        Me.nextLabel.Size = New System.Drawing.Size(48, 23)
        Me.nextLabel.TabIndex = 2
        Me.nextLabel.Text = "Next"
        Me.nextLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'scoreTextBox
        '
        Me.scoreTextBox.Location = New System.Drawing.Point(26, 32)
        Me.scoreTextBox.Name = "scoreTextBox"
        Me.scoreTextBox.ReadOnly = True
        Me.scoreTextBox.Size = New System.Drawing.Size(59, 21)
        Me.scoreTextBox.TabIndex = 1
        Me.scoreTextBox.TabStop = False
        Me.scoreTextBox.Text = "0"
        Me.scoreTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.scoreTextBox.WordWrap = False
        '
        'scoreLabel
        '
        Me.scoreLabel.Font = New System.Drawing.Font("Arial", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.scoreLabel.Location = New System.Drawing.Point(32, 8)
        Me.scoreLabel.Name = "scoreLabel"
        Me.scoreLabel.Size = New System.Drawing.Size(53, 23)
        Me.scoreLabel.TabIndex = 0
        Me.scoreLabel.Text = "Score"
        '
        'OpenFileDialog
        '
        Me.OpenFileDialog.CheckFileExists = False
        Me.OpenFileDialog.CheckPathExists = False
        Me.OpenFileDialog.DefaultExt = "lines"
        Me.OpenFileDialog.Filter = "Lines Files   *.lines|*.lines|All Files   *.*|*.*"
        Me.OpenFileDialog.InitialDirectory = ".."
        Me.OpenFileDialog.Title = "Load Saved Game..."
        '
        'SaveFileDialog
        '
        Me.SaveFileDialog.CheckPathExists = False
        Me.SaveFileDialog.DefaultExt = "lines"
        Me.SaveFileDialog.Filter = "Lines Files   *.lines|*.lines|All Files   *.*|*.*"
        Me.SaveFileDialog.InitialDirectory = ".."
        Me.SaveFileDialog.Title = "Save Game As..."
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 1
        Me.MenuItem2.Text = "User Manual"
        '
        'mainForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 14)
        Me.ClientSize = New System.Drawing.Size(368, 257)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Menu = Me.MainMenu
        Me.Name = "mainForm"
        Me.Text = "Lines"
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

#End Region

    ' Places next set of balls on field and choose next set
    Private Sub placeBallsOnField(ByVal firstTime As Boolean)
        Dim randomNumber As Integer = 0
        Dim nextBalls() As Label = {Me.Next1, Me.Next2, Me.Next3}
        Dim rand As New Random
        Dim i As Integer = 0
        Dim fieldIndex As Integer = 0
        color = Color.White

        If firstTime = True Then

            'initialize array of unoccupied/current fields
            availableFields = New ArrayList
            For i = 1 To Me.NUM_OF_FIELDS
                availableFields.Add(i - 1)
                fields(i - 1) = EMPTY_SPACE
            Next

            'choose balls for next placement
            chooseNextBalls()

            'put next set of balls on field
            For i = 0 To NUM_BALLS_TO_PLACE - 1
                randomNumber = rand.Next(0, (NUM_OF_FIELDS - 1))
                If CType(Me.Panel1.Controls.Item(randomNumber), Label).ImageIndex = EMPTY_SPACE Then
                    CType(Me.Panel1.Controls.Item(randomNumber), Label).ImageIndex =
                        nextBalls(i).ImageIndex
                    fields(randomNumber) = nextBalls(i).ImageIndex
                    availableFields.Remove(randomNumber)
                Else
                    i -= 1
                End If
            Next

            If availableFields.Count <> 61 Then
                Debug.Fail("We need 3 balls to start with. We have " + NUM_OF_FIELDS.ToString - availableFields.Count.ToString)
            End If

            'check if we have leaderboard table
            If Not top10.top10Results Is Nothing Then
                Me.topScoreTextBox.Text = CStr(top10.top10Results.GetValue(0))
            Else
                Me.scoreTextBox.Text = "0"
            End If
            'obviously step back is unavailable
            MenuItemStepBack.Enabled = False
        Else
            'this not the first time it runs
            MenuItemStepBack.Enabled = True

            For i = 0 To NUM_BALLS_TO_PLACE - 1
                If availableFields.Count > 0 Then
                    randomNumber = rand.Next(0, (availableFields.Count - 1))
                    fieldIndex = availableFields(randomNumber)
                    If CType(Me.Panel1.Controls.Item(fieldIndex), Label).ImageIndex = EMPTY_SPACE Then
                        CType(Me.Panel1.Controls.Item(fieldIndex), Label).ImageIndex =
                        nextBalls(i).ImageIndex
                        fields(fieldIndex) = nextBalls(i).ImageIndex

                        'delete the location from available fields
                        availableFields.Remove(fieldIndex)

                        fullRowsCheck(fieldIndex, nextBalls(i).ImageIndex)
                    Else
                        i -= 1
                    End If
                End If
            Next

            'space check
            If availableFields.Count = 0 Then
                'game over
                'get name if the score is in top 10
                Dim isTop10 As Boolean = top10.checkResult(Integer.Parse(Me.scoreTextBox.Text))

                If isTop10 = True Then
                    Me.topScoreTextBox.Text = Me.scoreTextBox.Text
                End If
                Exit Sub
            End If
        End If

#If DEBUG = True Then
        For i = 0 To 7
            Console.WriteLine("{0} {1} {2} {3} {4} {5} {6} {7}   {8}...{9}", fields(8 * i), fields(8 * i + 1), fields(8 * i + 2), fields(8 * i + 3), fields(8 * i + 4), fields(8 * i + 5), fields(8 * i + 6), fields(8 * i + 7), 8 * i, (8 * i + 7))
        Next
        Console.WriteLine("----------------------------------------------")
        For i = 0 To availableFields.Count - 1
            Console.Write("{0} ", availableFields(i))
        Next
        Console.WriteLine()
#End If
        'because random class is time-dependant we wait to have
        'a set of different results
        Thread.Sleep(30)

        chooseNextBalls()
    End Sub

    'Displays new random set of balls
    Private Sub chooseNextBalls()
        Dim randomNumber As Integer = 0
        Dim nextBalls() As Label = {Me.Next1, Me.Next2, Me.Next3}
        Dim rand As New Random
        Dim i As Integer = 0

        For i = 1 To NUM_BALLS_TO_PLACE
            If i <= availableFields.Count Then
                randomNumber = rand.Next(0, 4)
                nextBalls(i - 1).ImageIndex = 4 - randomNumber
                nextBalls(i - 1).Refresh()
            Else
                nextBalls(i - 1).ImageIndex = EMPTY_SPACE
                nextBalls(i - 1).Refresh()
            End If
            'this is done because of random number is time dependant value
            Thread.Sleep(randomNumber * 10 + 1)
        Next
    End Sub

    ' New game menu item
    Private Sub MenuItemNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItemNew.Click
        Dim i As Integer = 0
        For i = 1 To NUM_OF_FIELDS
            CType(Me.Panel1.Controls.Item(i - 1), Label).ImageIndex = EMPTY_SPACE
            fields(i - 1) = EMPTY_SPACE
        Next
        availableFields = New ArrayList
        placeBallsOnField(True)

        'reset score
        score = 0
        Me.scoreTextBox.Text = score.ToString
        Me.scoreTextBox.Refresh()
        scoreTextBox.Text = "0"

    End Sub

    'Exit menu item
    Private Sub MenuItemExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItemExit.Click
        Application.Exit()
    End Sub

    'Field click event handler. One for all fields
    Private Sub FieldN_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Field1.Click, Field2.Click, Field3.Click, Field4.Click, Field5.Click, Field6.Click, Field7.Click, Field8.Click, Field9.Click, Field10.Click,
        Field11.Click, Field12.Click, Field13.Click, Field14.Click, Field15.Click, Field16.Click, Field17.Click, Field18.Click, Field19.Click, Field20.Click,
        Field21.Click, Field22.Click, Field23.Click, Field24.Click, Field25.Click, Field26.Click, Field27.Click, Field28.Click, Field29.Click, Field30.Click,
        Field31.Click, Field32.Click, Field33.Click, Field34.Click, Field35.Click, Field36.Click, Field37.Click, Field38.Click, Field39.Click, Field40.Click,
        Field41.Click, Field42.Click, Field43.Click, Field44.Click, Field45.Click, Field46.Click, Field47.Click, Field48.Click, Field49.Click, Field50.Click,
        Field51.Click, Field52.Click, Field53.Click, Field54.Click, Field55.Click, Field56.Click, Field57.Click, Field58.Click, Field59.Click, Field60.Click,
        Field61.Click, Field62.Click, Field63.Click, Field64.Click

        If CType(sender, Label).ImageIndex <> EMPTY_SPACE Then
            'select ball
            If Not source Is Nothing Then
                source.BackColor = color
                source = CType(sender, Label)
                color = source.BackColor
                source.BackColor = SELECTED_COLOR
            Else
                source = CType(sender, Label)
                color = source.BackColor
                source.BackColor = SELECTED_COLOR
            End If

        Else
            'calculate the way to destination
            If Not source Is Nothing Then
                Dim i As Integer = 0
                finder = New pathFinder(fields, Me)
                Dim res As Boolean = finder.findPath(source.TabIndex, CType(sender, Label).TabIndex)
                If res = True Then
                    'save previous status
                    savePrevStatus()

                    source.BackColor = color
                    'show moves
                    Dim action As New ballMover(finder.getPath, source.ImageIndex, Me)
                    action.go()

                    fields(source.TabIndex) = EMPTY_SPACE
                    fields(CType(sender, Label).TabIndex) = CType(sender, Label).ImageIndex

                    'add source to availableFields and remove destination from availableFields
                    'because of ball movement
                    availableFields.Add(source.TabIndex)
                    'delete the location from available fields
                    availableFields.Remove((CType(sender, Label).TabIndex))

                    If fullRowsCheck(CType(sender, Label).TabIndex, CType(sender, Label).ImageIndex) = False Then
                        'no full rows were found
                        placeBallsOnField(False)
                    End If

                    source = Nothing
                Else
                    'display cross to let player know ther is no path found
                    CType(sender, Label).ImageIndex = NO_MOVE_IMAGE_INDEX
                    CType(sender, Label).Refresh()
                    Thread.Sleep(200)
                    CType(sender, Label).ImageIndex = EMPTY_SPACE
                    CType(sender, Label).Refresh()
                End If
            Else
                'select the ball
                If Not source Is Nothing Then
                    source.BackColor = color
                    source = CType(sender, Label)
                    color = source.BackColor
                    source.BackColor = SELECTED_COLOR
                Else
                    source = CType(sender, Label)
                    color = source.BackColor
                    source.BackColor = SELECTED_COLOR
                End If
            End If
            CType(sender, Label).Refresh()
        End If
    End Sub

    'save status field for step back
    Private Sub savePrevStatus()
        Dim i As Integer = 0

        For i = 1 To NUM_OF_FIELDS
            prevStatus(i - 1) = CType(Me.Panel1.Controls.Item(i - 1), Label).ImageIndex
        Next
        prevScore = Me.scoreTextBox.Text
    End Sub

    'Step back
    Private Sub restorePrevStatus()
        Dim i As Integer = 0

        'reset available fields array because the situation is about to be stepped back
        availableFields = Nothing
        availableFields = New ArrayList

        For i = 1 To NUM_OF_FIELDS
            CType(Me.Panel1.Controls.Item(i - 1), Label).ImageIndex = prevStatus(i - 1)
            If CType(Me.Panel1.Controls.Item(i - 1), Label).ImageIndex = EMPTY_SPACE Then
                availableFields.Add(i - 1)
            End If
            fields(i - 1) = prevStatus(i - 1)
        Next
        Me.scoreTextBox.Text = prevScore
        score = Integer.Parse(prevScore)
        prevScore = ""
    End Sub

    'Check for full rows and erase them
    'returns True if full row is found, othewise False
    Private Function fullRowsCheck(ByVal fieldIndex As Integer, ByVal colorIndex As Integer) As Boolean
        Dim indexCombination As New ArrayList
        Dim isFullRow As Boolean = False
        Dim count As Integer = 0
        'to check if we hit the end of balls row
        Dim firstLimit As Boolean = False, secondLimit As Boolean = False
        Dim i As Integer = 0, result As Integer = 0, reminder As Integer = 0, position As Integer = 0

        'do check for full rows

        'check for the left/right borders of the field
        result = Math.DivRem(fieldIndex, mainForm.SIZE_OF_ROW, reminder)

        indexCombination.Add(fieldIndex)

        'do HORIZONTAL - 8=max number of balls of the same color
        count = 1
        For i = 1 To 8
            'i hate vb
            If (reminder - i) >= 0 Then
                If fields.GetValue(fieldIndex - i) = colorIndex And firstLimit = False Then
                    count += 1
                    indexCombination.Add(fieldIndex - i)
                    firstLimit = False
                Else
                    firstLimit = True
                End If
            End If
            If (reminder + i) <= (mainForm.SIZE_OF_ROW - 1) Then
                If fields.GetValue(fieldIndex + i) = colorIndex And secondLimit = False Then
                    count += 1
                    indexCombination.Add(fieldIndex + i)
                    secondLimit = False
                Else
                    secondLimit = True
                End If
            End If
        Next
        If count < 5 Then
            'leave original ball intact (-1) as it maybe other combinations there
            indexCombination.RemoveRange(indexCombination.Count - count + 1, count - 1)
        Else
            isFullRow = True
        End If

        'do VERTICAL - 8=max number of balls of the same color
        count = 1
        firstLimit = False
        secondLimit = False
        For i = 1 To 8
            position = fieldIndex - mainForm.SIZE_OF_ROW * i

            If position >= 0 Then
                If fields.GetValue(position) = colorIndex And firstLimit = False Then
                    count += 1
                    indexCombination.Add(position)
                    firstLimit = False
                Else
                    firstLimit = True
                End If
            End If
            position = fieldIndex + mainForm.SIZE_OF_ROW * i
            If position <= (mainForm.NUM_OF_FIELDS - 1) Then
                If fields.GetValue(position) = colorIndex And secondLimit = False Then
                    count += 1
                    indexCombination.Add(position)
                    secondLimit = False
                Else
                    secondLimit = True
                End If
            End If
        Next
        If count < 5 Then
            indexCombination.RemoveRange(indexCombination.Count - count + 1, count - 1)
        Else
            isFullRow = True
        End If

        'do DIAGONAL LEFT - 10=max number of balls of the same color
        count = 1
        firstLimit = False
        secondLimit = False
        For i = 1 To 10
            position = fieldIndex - mainForm.SIZE_OF_ROW * i - i

            If position >= 0 And (reminder - i) >= 0 Then
                If fields.GetValue(position) = colorIndex And firstLimit = False Then
                    count += 1
                    indexCombination.Add(position)
                    firstLimit = False
                Else
                    firstLimit = True
                End If
            End If
            position = fieldIndex + mainForm.SIZE_OF_ROW * i + i
            If position <= (mainForm.NUM_OF_FIELDS - 1) And (reminder + i) <= (mainForm.SIZE_OF_ROW - 1) Then
                If fields.GetValue(position) = colorIndex And secondLimit = False Then
                    count += 1
                    indexCombination.Add(position)
                    secondLimit = False
                Else
                    secondLimit = True
                End If
            End If
        Next
        If count < 5 Then
            indexCombination.RemoveRange(indexCombination.Count - count + 1, count - 1)
        Else
            isFullRow = True
        End If

        'do DIAGONAL RIGHT - 10=max number of balls of the same color
        count = 1
        firstLimit = False
        secondLimit = False
        For i = 1 To 10
            position = fieldIndex - mainForm.SIZE_OF_ROW * i + i
            'bloody vb
            If position >= 0 And (reminder + i) <= (mainForm.SIZE_OF_ROW - 1) Then
                If fields.GetValue(position) = colorIndex And firstLimit = False Then
                    count += 1
                    indexCombination.Add(position)
                    firstLimit = False
                Else
                    firstLimit = True
                End If
            End If
            position = fieldIndex + mainForm.SIZE_OF_ROW * i - i
            If position <= (mainForm.NUM_OF_FIELDS - 1) And (reminder - i) >= 0 Then
                If fields.GetValue(position) = colorIndex And secondLimit = False Then
                    count += 1
                    indexCombination.Add(position)
                    secondLimit = False
                Else
                    secondLimit = True
                End If
            End If
        Next

        If count < 5 Then
            indexCombination.RemoveRange(indexCombination.Count - count + 1, count - 1)
        Else
            isFullRow = True
        End If

        'call erase combination method
        If isFullRow = True Then eraseCombination(indexCombination.ToArray(Type.GetType("System.Int32")))

        Return isFullRow
    End Function

    'Erase combination of balls
    Private Sub eraseCombination(ByVal indexArray() As Integer)
        Dim i As Integer = 0
        Dim index As Integer = 0

        For i = 1 To indexArray.Length
            index = indexArray(i - 1)
            CType(Me.Panel1.Controls.Item(index), Label).ImageIndex = EMPTY_SPACE
            fields(index) = EMPTY_SPACE
            availableFields.Add(index)
            score += 1
        Next

        'update score
        Me.scoreTextBox.Text = score.ToString
        Me.scoreTextBox.Refresh()
    End Sub

    'Show About... box
    Private Sub MenuItemAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItemAbout.Click
        Dim about As New about
        about.Left = Me.Left + 30
        about.Top = Me.Top + 30

        about.ShowDialog()
    End Sub

    Private Sub MenuItemStepBack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItemStepBack.Click
        restorePrevStatus()
        MenuItemStepBack.Enabled = False
        chooseNextBalls()
    End Sub

    Private Sub MenuItemBestResults_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItemBestResults.Click
        top10.Left = Me.Left + 10
        top10.Top = Me.Top + 10
        top10.ShowDialog()
    End Sub

    Private Sub MenuItemSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItemSave.Click
        Dim fs As System.IO.FileStream
        Dim bytes(NUM_OF_FIELDS - 1), nextBytes(NUM_BALLS_TO_PLACE - 1), separator As Byte
        Dim sepChar As Char = "&"
        Dim i As Integer = 0
        Dim score() As Byte = New System.Text.UTF8Encoding(True).GetBytes(Me.scoreTextBox.Text)
        Dim nextBalls() As Integer = {Me.Next1.ImageIndex, Me.Next2.ImageIndex, Me.Next3.ImageIndex}

        Me.SaveFileDialog.ShowDialog()

        Try
            If SaveFileDialog.FileName <> "" Then
                fs = SaveFileDialog.OpenFile()
                bytes = IntArrayToByteArray(fields)
                For i = 0 To bytes.Length - 1
                    bytes(i) = bytes(i) Xor i
                Next
                fs.Write(bytes, 0, fields.Length)
                For i = 0 To score.Length - 1
                    score(i) = score(i) Xor i
                Next
                fs.Write(score, 0, score.Length)
                separator = System.Convert.ToByte(sepChar)
                fs.WriteByte(separator)
                nextBytes = IntArrayToByteArray(nextBalls)
                fs.Write(nextBytes, 0, nextBytes.Length)

                fs.Flush()
                fs.Close()
            End If
        Catch ex As System.IO.IOException
            MessageBox.Show(ex.Message, "Problem with file save...", MessageBoxButtons.OK,
                            MessageBoxIcon.Error, Nothing, Nothing)
        End Try
    End Sub

    Private Sub MenuItemLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItemLoad.Click
        Dim fs As System.IO.FileStream
        Dim bytes(NUM_OF_FIELDS - 1), nextBytes(NUM_BALLS_TO_PLACE - 1), separator As Byte
        Dim score(4), scoreByte As Byte
        Dim trimChar() As Char = {Chr(30)}
        Dim sepChar As Char = "&"
        Dim i, nextBallColor(NUM_BALLS_TO_PLACE - 1) As Integer
        Dim nextBalls() As Label = {Me.Next1, Me.Next2, Me.Next3}

        Me.OpenFileDialog.ShowDialog()

        Try
            If OpenFileDialog.FileName <> "" Then
                fs = OpenFileDialog.OpenFile()
                fs.Read(bytes, 0, NUM_OF_FIELDS)

                For i = 0 To bytes.Length - 1
                    bytes(i) = bytes(i) Xor i
                Next

                fields = ByteArrayToIntArray(bytes)

                'restoring the field state
                For i = 0 To NUM_OF_FIELDS - 1
                    CType(Me.Panel1.Controls.Item(i), Label).ImageIndex = fields(i)
                Next

                'read until delimiter is found (I think it may be done better)
                i = 0
                separator = System.Convert.ToByte(sepChar)
                scoreByte = fs.ReadByte()
                While (scoreByte) <> separator
                    score(i) = scoreByte
                    i += 1
                    scoreByte = fs.ReadByte()
                End While

                For i = 0 To score.Length - 1
                    score(i) = score(i) Xor i
                    If score(i) < 40 Or score(i) > 48 Then
                        score(i) = 30 ' " "
                    End If
                Next
                'restore score
                Me.scoreTextBox.Text = (New System.Text.UTF8Encoding(True).GetString(score)).Trim(trimChar)

                'restore next set of balls
                fs.Read(nextBytes, 0, 3)

                nextBallColor = ByteArrayToIntArray(nextBytes)
                For i = 0 To NUM_BALLS_TO_PLACE - 1
                    nextBalls(i).ImageIndex = nextBallColor(i)
                Next

                fs.Close()
            End If
        Catch ex As System.IO.IOException
            MessageBox.Show(ex.Message, "Problem with file load...", MessageBoxButtons.OK,
                            MessageBoxIcon.Error, Nothing, Nothing)
        End Try
    End Sub

    'convert Integer array into Byte array
    Private Function IntArrayToByteArray(ByVal intArray() As Integer) As Byte()
        Dim i As Integer = 0
        Dim byteArray(intArray.Length - 1) As Byte

        For i = 0 To intArray.Length - 1
            If intArray(i) = EMPTY_SPACE Then
                byteArray(i) = 255
            Else
                byteArray(i) = System.Convert.ToByte(intArray(i))
            End If
        Next

        Return byteArray
    End Function

    'convert Byte array into Integer array
    Private Function ByteArrayToIntArray(ByVal byteArray() As Byte) As Integer()
        Dim i As Integer = 0
        Dim intArray(byteArray.Length - 1) As Integer

        For i = 0 To byteArray.Length - 1
            If byteArray(i) = 255 Then
                intArray(i) = EMPTY_SPACE
            Else
                intArray(i) = System.Convert.ToInt32(byteArray(i))
            End If
        Next

        Return intArray
    End Function

    'User manual button
    Private Sub MenuItem2_Click(sender As Object, e As EventArgs) Handles MenuItem2.Click
        System.Diagnostics.Process.Start("https://docs.google.com/document/d/12iQqoRDqcF_dSwrDm5sUOehuxQg_M4jeTZJM_8WYdSg/edit")
    End Sub
End Class
